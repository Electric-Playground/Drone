document.addEventListener('DOMContentLoaded', () => {
    const manualButton = document.getElementById('manual-mode');
    const autoButton = document.getElementById('auto-mode');
    const videoFeed = document.getElementById('video-feed');
    const speedInput = document.getElementById('speed');
    const batteryInput = document.getElementById('battery');
    const altitudeInput = document.getElementById('altitude');
    const altitudeDecrement = document.getElementById('altitude-decrement');
    const altitudeIncrement = document.getElementById('altitude-increment');
    const redLight = document.getElementById('red-light');
    const greenLight = document.getElementById('green-light');

    // Handle mode switching
    manualButton.addEventListener('click', () => {
        manualButton.style.backgroundColor = 'lightblue';
        autoButton.style.backgroundColor = '';
        // Implement functionality for manual mode
    });

    autoButton.addEventListener('click', () => {
        autoButton.style.backgroundColor = 'lightblue';
        manualButton.style.backgroundColor = '';
        // Implement functionality for auto mode
    });

    // Update live video feed (this is just a placeholder)
    // In a real scenario, you would use an actual video source
    // navigator.mediaDevices.getUserMedia({ video: true })
    //     .then(stream => videoFeed.srcObject = stream)
    //     .catch(err => console.error('Error accessing camera: ', err));

    // Handle altitude increment and decrement
    altitudeDecrement.addEventListener('click', () => {
        altitudeInput.value = Math.max(0, parseInt(altitudeInput.value) - 1);
    });

    altitudeIncrement.addEventListener('click', () => {
        altitudeInput.value = parseInt(altitudeInput.value) + 1;
    });

    // Optionally: Handle changes in speed and battery inputs
    speedInput.addEventListener('input', () => {
        console.log('Speed:', speedInput.value);
    });

    batteryInput.addEventListener('input', () => {
        console.log('Battery Percentage:', batteryInput.value);
    });
});
